package com.hstn.springapp.dbconnection;

import com.hstn.springapp.entities.Movies;


import java.sql.*;
import java.util.ArrayList;

public class PostgresDB {
    private final String url = "jdbc:postgresql://localhost:5432/demo";
    private final String username = "postgres";
    private final String password = "dastanse2424oop";

    public Connection connect() throws Exception {
        Connection con = DriverManager.getConnection(url, username, password);
        System.out.println("Connected to database");
        return con;
    }

    public int disconnect(Connection con) throws SQLException {
        if (con != null) {
            con.close();
            System.out.println("Disconnected from database");
            return 0;
        }
        System.out.println("No connection to database");
        return 1;
    }

    public ArrayList<Movies> getMovies(Connection con) throws SQLException {
        String query = "SELECT * FROM public.movies";
        Statement st = con.createStatement();
        ResultSet rs = st.executeQuery(query);
        ArrayList<Movies> movies = new ArrayList<>();
        while (rs.next()) {
            Movies movie = new Movies(rs.getInt("id"), rs.getString("name"), rs.getString("genre"));
            movies.add(movie);
        }
        st.close();
        disconnect(con);
        return movies;
    }

    public Movies findMovieById(Connection con, int id) throws SQLException {
        String query = "SELECT * FROM public.movies WHERE id = ?";
        PreparedStatement st = con.prepareStatement(query);
        st.setInt(1, id);
        ResultSet rs = st.executeQuery();
        if (rs.next()) {
            return new Movies(rs.getInt("id"), rs.getString("name"), rs.getString("genre"));
        }
        st.close();
        disconnect(con);
        return null;
    }

    public Movies createMovie(Connection con, Movies movie) throws SQLException {
        String query = "INSERT INTO public.movies (name, genre) VALUES (?, ?) RETURNING id";
        PreparedStatement st = con.prepareStatement(query);
        st.setString(1, movie.getName());
        st.setString(2, movie.getGenre());
        ResultSet rs = st.executeQuery();
        if (rs.next()) {
            movie.setId(rs.getInt("id"));
        }
        st.close();
        disconnect(con);
        return movie;
    }
    public boolean deleteMovie(Connection con, int id) throws SQLException {
        String query = "DELETE FROM public.movies WHERE id=?";
        PreparedStatement st = con.prepareStatement(query);
        st.setInt(1, id);

        int rowsAffected = st.executeUpdate();
        st.close();

        return rowsAffected > 0; // Возвращает true, если удаление прошло успешно
    }

}





package com.hstn.springapp.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hstn.springapp.dbconnection.PostgresDB;
import com.hstn.springapp.entities.Movies;
import org.springframework.web.bind.annotation.*;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

@RestController
@RequestMapping("/main") // добавлено для унификации URL
public class MyController {

    private final ObjectMapper oMapper;

    public MyController(ObjectMapper objectMapper) {
        this.oMapper = objectMapper;
    }

    @GetMapping("/movies")
    public String myMovieListener() {
        Movies movie1 = new Movies(1, "Inception", "Sci-Fi");
        try {
            return oMapper.writeValueAsString(movie1);
        } catch (JsonProcessingException e) {
            System.out.println("JSON error: " + e.getMessage());
            return "{}";
        }
    }

    @PostMapping("/custommovies")
    public String myCustomMovieListener(@RequestParam int id, @RequestParam String name, @RequestParam String genre) {
        Movies movie1 = new Movies(id, name, genre);
        try {
            return oMapper.writeValueAsString(movie1);
        } catch (JsonProcessingException e) {
            System.out.println("JSON error: " + e.getMessage());
            return "{}";
        }
    }

    @GetMapping("/allMovies")
    public String myAllMoviesListener() {
        PostgresDB myConnection = new PostgresDB();
        ArrayList<Movies> movies = new ArrayList<>();
        try (Connection con = myConnection.connect()) {
            movies = myConnection.getMovies(con);
        } catch (Exception e) {
            System.out.println("Error getting all movies: " + e.getMessage());
        }

        try {
            return oMapper.writeValueAsString(movies);
        } catch (JsonProcessingException e) {
            System.out.println("JSON error: " + e.getMessage());
            return "{}";
        }
    }

    @PostMapping("/findMovies")
    public String myFindMovieListener(@RequestParam int id) {
        PostgresDB myConnection = new PostgresDB();
        Movies movie1 = null;
        try (Connection con = myConnection.connect()) {
            movie1 = myConnection.findMovieById(con, id);
        } catch (Exception e) {
            System.out.println("Error finding movie: " + e.getMessage());
        }

        try {
            return oMapper.writeValueAsString(movie1);
        } catch (Exception e) {
            System.out.println("JSON error: " + e.getMessage());
            return "{}";
        }
    }

    @PostMapping("/createMovie")
    public String myCreateMovieListener(@RequestParam int id, @RequestParam String name, @RequestParam String genre) {
        PostgresDB myConnection = new PostgresDB();
        Movies movie1 = new Movies(id, name, genre);
        String jsonData = null;
        try (Connection con = myConnection.connect()) {
            Movies createdMovie = myConnection.createMovie(con, movie1);
            jsonData = oMapper.writeValueAsString(createdMovie);
        } catch (JsonProcessingException e) {
            System.out.println("JSON error: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("SQL error: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Unexpected error: " + e.getMessage());
        }
        return jsonData != null ? jsonData : "{}";
    }
    @DeleteMapping("/deleteMovie")
    public String deleteMovie(@RequestParam int id) {
        PostgresDB myConnection = new PostgresDB();
        boolean deleted = false;
        try (Connection con = myConnection.connect()) {
            deleted = myConnection.deleteMovie(con, id);
        } catch (Exception e) {
            System.out.println("Error deleting movie: " + e.getMessage());
        }

        if (deleted) {
            return "{\"message\": \"Movie deleted successfully\"}";
        } else {
            return "{\"message\": \"Movie not found or could not be deleted\"}";
        }
    }
}








